ساخت APK اندروید برای Shooter3D
================================

این پروژه برای بسته‌بندی بازی با Capacitor آماده شده است. فایل APK در این محیط ساخته نشده؛ چون Android SDK، Gradle و Android Studio نصب نیستند.

پیش‌نیاز روی کامپیوتر ویندوز:
- Android Studio به‌همراه Android SDK و Build Tools
- JDK 17
- Node.js نسخه 18 یا جدیدتر

مراحل:
1) این پوشه را از ZIP خارج کنید.
2) در پوشه اصلی Shooter3D ترمینال باز کنید.
3) اجرا کنید:
   npm install
   npm run android:add
   npm run android:sync
   npm run android:open
4) در Android Studio منتظر بمانید Gradle Sync تمام شود.
5) از منوی Build > Build Bundle(s) / APK(s) > Build APK(s) را انتخاب کنید.

خروجی APK:
   android/app/build/outputs/apk/debug/app-debug.apk

برای ساخت APK قابل انتشار:
   Build > Generate Signed Bundle / APK

کنترل اسلاید:
- موبایل: دکمه «اسلاید» روی صفحه (در حالت افقی)
- ویندوز: کلید Ctrl

نکته:
- فایل index.html اصلی بازی در پوشه www قرار گرفته و به‌عنوان محتوای آفلاین داخل APK بسته‌بندی می‌شود.
- در اولین اجرای npm install به اینترنت نیاز است تا وابستگی‌های Capacitor دریافت شوند.
- برای ساخت APK نهایی، باید مراحل بالا روی رایانه‌ای که Android SDK دارد اجرا شود.
