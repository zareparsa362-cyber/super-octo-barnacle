ساخت فایل exe ویندوز (نیاز به Node.js و اینترنت فقط برای یک بار نصب):
1) Node.js را از nodejs.org نصب کنید.
2) در همین پوشه CMD باز کنید و بزنید:  npm install
3) برای تست:  npm start
4) برای ساخت exe قابل حمل:  npm run dist   (خروجی در پوشهٔ dist)
