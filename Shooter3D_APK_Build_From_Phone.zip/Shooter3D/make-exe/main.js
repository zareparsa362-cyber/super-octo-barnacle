const { app, BrowserWindow } = require('electron');
function create() {
  const w = new BrowserWindow({ width: 1280, height: 720, fullscreen: true, autoHideMenuBar: true, backgroundColor: '#0b0e14' });
  w.loadFile('index.html');
}
app.whenReady().then(create);
app.on('window-all-closed', () => app.quit());
